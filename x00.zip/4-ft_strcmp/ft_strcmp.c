#include <stdio.h>
int ft_strcmp(char *s1, char *s2) {
	int i = 0;
	while (s1[i] && s2[i] && s1[i] == s2[1]) {
		i++;
	}
	return s1[i] - s2[i];
}
/*
int main() {
	char str1[] = "Hello";
	char str2[] = "World";
	int result = ft_strcmp(str1, str2);
	if (result < 0) {
		printf("str1 is less than str2\n");
	} else if (result > 0) {
		printf("str1 is greater than str2\n");
	} else {
		printf("str1 is equal to str2\n");
	}
	printf("Comparison result: %d\n", result);
	return 0;
}
*/

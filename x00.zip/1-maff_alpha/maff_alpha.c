#include <unistd.h>
int main() {
	char even = 'B';
	char odd = 'a';
	while (odd <= 'z') {
		write(1, &odd, 1);
		write(1, &even, 1);
		odd += 2;
		even += 2;
	}
	write(1, "\n", 1);
	return 0;
}

#include <unistd.h>
int main() {
	write(1, "Hello World!", 13);
	return 0;
}
